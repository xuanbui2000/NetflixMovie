﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project_PlantShop.Data;
using Project_PlantShop.Models;
using System.Diagnostics;

namespace Project_PlantShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
       
            private readonly PlantContext _context;
            private readonly IWebHostEnvironment _host;
        //private readonly UserManager<PlantUser> _userManager;
        //private readonly SignInManager<PlantUser> _signInManager;
        //private readonly RoleManager<IdentityRole<int>> _roleManager;

        //public HomeController(UserManager<PlantUser> userManager, RoleManager<IdentityRole<int>> roleManager, SignInManager<PlantUser> signInManager, PlantContext context, IWebHostEnvironment host)
        //{
        //    _roleManager = roleManager;
        //    _userManager = userManager;
        //    _signInManager = signInManager;
        //    _context = context;
        //    _host = host;
        //}
       
        public HomeController(ILogger<HomeController> logger, PlantContext context)
        {
            _logger = logger;
            _context = context;

        }
        
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? pageNumber)
        {
            List<Specie>listSpecies= _context.Species.ToList();
            ViewBag.Categories = listSpecies;
            var plantContext = _context.Plants.Include(p => p.Species);
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";
            ViewData["RateSortParm"] = sortOrder == "Rate" ? "rate_desc" : "Rate";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var plant = from s in _context.Plants
                        select s;
           
            if (!String.IsNullOrEmpty(searchString))
            {
                plant = plant.Where(x => x.Name.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "title_desc":
                    plant = plant.OrderByDescending(s => s.Name);
                    break;
                case "Date":
                    plant = plant.OrderBy(s => s.Dob);
                    break;
                case "date_desc":
                    plant = plant.OrderByDescending(s => s.Dob);
                    break;
                case "Price":
                    plant = plant.OrderBy(s => s.Price);
                    break;
                case "price_desc":
                    plant = plant.OrderByDescending(s => s.Price);
                    break;
                case "Rate":
                    plant = plant.OrderBy(s => s.Rating);
                    break;
                case "rate_desc":
                    plant = plant.OrderByDescending(s => s.Rating);
                    break;
                default:
                    plant = plant.OrderBy(s => s.Name);
                    break;
            }
            int pageSize = 5;
            return View(await PaginatedList<Plant>.CreateAsync(plant.AsNoTracking(), pageNumber ?? 1, pageSize));
        }
       
        public async Task<IActionResult> Specie(int id, string sortOrder, string currentFilter, string searchString, int? pageNumber)
        {
            ViewBag.NameSpecie = _context.Species.FirstOrDefault(x => x.Id == id).Name;   
            var plantContext = _context.Plants.Include(p => p.Species);
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";
            ViewData["RateSortParm"] = sortOrder == "Rate" ? "rate_desc" : "Rate";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var plant = from s in _context.Plants where s.SpecieId== id
                        select s;

            if (!String.IsNullOrEmpty(searchString))
            {
                plant = plant.Where(x => x.Name.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "title_desc":
                    plant = plant.OrderByDescending(s => s.Name);
                    break;
                case "Date":
                    plant = plant.OrderBy(s => s.Dob);
                    break;
                case "date_desc":
                    plant = plant.OrderByDescending(s => s.Dob);
                    break;
                case "Price":
                    plant = plant.OrderBy(s => s.Price);
                    break;
                case "price_desc":
                    plant = plant.OrderByDescending(s => s.Price);
                    break;
                case "Rate":
                    plant = plant.OrderBy(s => s.Rating);
                    break;
                case "rate_desc":
                    plant = plant.OrderByDescending(s => s.Rating);
                    break;
                default:
                    plant = plant.OrderBy(s => s.Name);
                    break;
            }
            int pageSize = 10;
            return View(await PaginatedList<Plant>.CreateAsync(plant.AsNoTracking(), pageNumber ?? 1, pageSize)); 
        }
        
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || _context.Plants == null)
            {
                return NotFound();
            }

            var plant = await _context.Plants
                .Include(p => p.Species)
                .Include(p => p.Company)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (plant == null)
            {
                return NotFound();
            }

            return View(plant);
        }
        public IActionResult Privacy()
        {
            return View();
        }
        [HttpPost]
        //public IActionResult AddToCard(int id, int quantities)
        //{
        //    var user = await UserManager.FindByNameAsync(User.Identity.Name);
        //    Plant plant = _context.Plants.FirstOrDefault(s => s.Id==id);
        //    if (quantities >plant.Quantity)
        //    {
        //        return View();
        //    }
        //    else {
        //        return View();
        //    }
            
        //}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}